<!-- Mobile menu toggle button (hamburger/x icon) -->
<input id="main-menu-state" type="checkbox" />
<label class="main-menu-btn sub-menu-triger" for="main-menu-state">
  <span class="main-menu-btn-icon"></span>
</label>

<!-- Primary Navigation
============================================= -->
<nav id="primary-menu" class="menu main-menu head-item">
	<?php foja_main_nav_menu(); ?>
</nav>
<!-- end primary menu -->