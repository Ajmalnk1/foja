<div class="header-social head-item">
	<ul>
	    <?php foja_social_profile(); ?>
	</ul>
</div>