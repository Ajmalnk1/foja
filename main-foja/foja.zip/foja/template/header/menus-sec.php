<!-- Primary Navigation
============================================= -->
<nav id="secondary-menu" class="menu main-menu head-item">
	<?php foja_main_nav_menu_left(); ?>
</nav>
<!-- end primary menu -->