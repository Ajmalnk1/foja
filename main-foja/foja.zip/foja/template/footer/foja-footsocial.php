<div class="social-footer foot-col-item">
	<ul>
		<?php foja_social_profile(); ?>
	</ul>
</div>