<div class="footer-menu foot-col-item">
	<?php foja_footer_menu(); ?>
</div>