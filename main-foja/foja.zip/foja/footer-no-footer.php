<!-- FOOTER -->

</div>
<!-- MAIN WRAPPER END -->

<?php wp_footer(); ?>

</body>
</html>